data:extend(
{
   {
    type = "bool-setting",
    name = "angels-use-angels-barreling",
    setting_type = "startup",
    default_value = true,
    order = "a",
   },
}
)


