local function paste_direction(event)
  local s = event.source
  local d = event.destination

  if s.supports_direction and d.supports_direction and
	s.prototype.fast_replaceable_group == "assembling-machine" and d.prototype.fast_replaceable_group == "assembling-machine" then
    d.direction = s.direction
  end
end

script.on_event(defines.events.on_entity_settings_pasted, paste_direction)
