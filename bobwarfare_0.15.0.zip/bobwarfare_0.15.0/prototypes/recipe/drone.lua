data:extend(
{
  {
    type = "recipe",
    name = "bob-robot-tank",
    enabled = "false",
    ingredients =
    {
      {"electric-engine-unit", 5},
      {"steel-plate", 30},
      {"iron-gear-wheel", 20},
      {"advanced-circuit", 10},
      {"processing-unit", 10},
      {"laser-turret", 1},
    },
    result = "bob-robot-tank"
  },
}
)

