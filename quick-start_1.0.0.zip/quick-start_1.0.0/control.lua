script.on_event(defines.events.on_player_created, function(event)
	local player = game.players[event.player_index]
	local quickbar = player.get_inventory(defines.inventory.player_quickbar)
	
	local items = {
		{"steel-axe", 10},
		{"iron-plate", 592},
		{"copper-plate", 400},
		{"iron-gear-wheel", 200},
		{"electronic-circuit", 200},
		{"transport-belt", 1100},
		{"underground-belt", 50},
		{"splitter", 50},
		{"stone-furnace", 100},
		{"assembling-machine-1", 20},
		{"inserter", 300},
		{"long-handed-inserter", 50},
		{"steel-chest", 50},
		{"electric-mining-drill", 50},
		{"small-electric-pole", 200},
		{"boiler", 10},
		{"steam-engine", 20},
		{"offshore-pump", 1},
		{"pipe-to-ground", 50},
		{"pipe", 50},
		{"car", 1},
		{"coal", 200},
		{"construction-robot", 50},
		{"lab", 10},
		{"deconstruction-planner", 1},
		{"power-armor", 1}
	}
	
	local armorItems = {
		{"fusion-reactor-equipment"},
		{"personal-roboport-equipment"},
		{"personal-roboport-equipment"},
		{"battery-equipment"},
		{"battery-equipment"},
		{"personal-roboport-equipment"},
		{"battery-equipment"},
		{"battery-equipment"},
		{"personal-roboport-equipment"},
		{"personal-roboport-equipment"},
		{"personal-roboport-equipment"},
		{"battery-equipment"},
		{"battery-equipment"}
	}
	
	-- Setup quickbar favorites
	quickbar.clear()
	quickbar.set_filter(1, "transport-belt")
	quickbar.set_filter(2, "underground-belt")
	quickbar.set_filter(3, "splitter")
	quickbar.set_filter(4, "inserter")
	quickbar.set_filter(5, "small-electric-pole")
	quickbar.set_filter(6, "deconstruction-planner")
	quickbar.set_filter(10, "car")
	
	-- Add items
	for k,v in pairs(items) do
		player.insert{name = v[1], count = v[2]}
	end
	
	-- Setup armor grid
	local grid = player.get_inventory(5)[1].grid
	for k,v in pairs(armorItems) do
		grid.put{name = v[1]}
	end
end)