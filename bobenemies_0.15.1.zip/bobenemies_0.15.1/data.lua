if not bobmods then bobmods = {} end
if not bobmods.enemies then bobmods.enemies = {} end


if settings.startup["bobmods-enemies-enableartifacts"].value == true then
  require("prototypes.alien-artifact")

  if settings.startup["bobmods-enemies-enablesmallartifacts"].value == true then
    require("prototypes.small-alien-artifact")
  end

  if settings.startup["bobmods-enemies-enablenewartifacts"].value == true then
    require("prototypes.new-alien-artifact")
    if settings.startup["bobmods-enemies-enablesmallartifacts"].value == true then
      require("prototypes.new-small-alien-artifact")
    end
  end
end


require("prototypes.damage-type")
require("prototypes.entities")
require("prototypes.projectiles")
require("prototypes.values")
require("prototypes.biters")
require("prototypes.spitters")
require("prototypes.spawners")
require("prototypes.worms")

