require("prototypes.assembly-updates")

if settings.startup["bobmods-assembly-electronicmachines"].value == true then
  require("prototypes.assembly-electronics-updates")
end

if settings.startup["bobmods-assembly-oilrefineries"].value == true then
  require("prototypes.oil-refinery-updates")
end

if settings.startup["bobmods-assembly-chemicalplants"].value == true then
  require("prototypes.chemical-plant-updates")
end

if settings.startup["bobmods-assembly-furnaces"].value == true then
  require("prototypes.electric-furnace-updates")
end

if settings.startup["bobmods-assembly-electrolysers"].value and 
  data.raw.technology["electrolysis-1"] and
  data.raw.item["electrolyser"] and
  data.raw["recipe-category"]["electrolysis"] then
  require("prototypes.electrolyser-updates")
end

if settings.startup["bobmods-assembly-multipurposefurnaces"].value and
  data.raw["item-subgroup"]["bob-smelting-machine"] and
  data.raw["recipe-category"]["chemical-furnace"] and
  data.raw["recipe-category"]["mixing-furnace"] and
  data.raw.technology["alloy-processing-2"] and
  data.raw.technology["chemical-processing-3"] then
  require("prototypes.chemical-mixing-furnace")
  require("prototypes.chemical-mixing-furnace-updates")
end

