require("prototypes/enemies/AttackAcidBall")
require("prototypes/enemies/AttackAcidFlame")

require("prototypes/buildings/tunnel")

require("prototypes/tile/fillableDirt")

require("prototypes/enemies/UnitSuicideBiters")
require("prototypes/enemies/UnitFireSpitters")
