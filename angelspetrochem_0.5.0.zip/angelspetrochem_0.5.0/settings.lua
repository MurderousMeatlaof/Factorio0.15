data:extend(
{
   {
    type = "bool-setting",
    name = "angels-hide-converter",
    setting_type = "startup",
    default_value = true,
    order = "a",
   },
   {
    type = "bool-setting",
    name = "angels-enable-acid-override",
    setting_type = "startup",
    default_value = true,
    order = "b",
   },
}
)


