function electrolyserpictures()
  return
  {
    north =
    {
      filename = "__angelspetrochem__/graphics/entity/electrolyser/blank.png",
      priority = "extra-high",
      width = 1,
      height = 1,
      shift = {-0.08, 0.45}
    },
    east =
    {
      filename = "__angelspetrochem__/graphics/entity/electrolyser/blank.png",
      priority = "extra-high",
      width = 1,
      height = 1,
      shift = {0, 0}
    },
    south =
    {
      filename = "__angelspetrochem__/graphics/entity/electrolyser/pipe-south.png",
      priority = "extra-high",
      width = 48,
      height = 48,
      shift = {0.06, -0.4}
    },
    west =
    {
      filename = "__angelspetrochem__/graphics/entity/electrolyser/blank.png",
      priority = "extra-high",
      width = 1,
      height = 1,
      shift = {0.62, 0.05}
    }
  }
end