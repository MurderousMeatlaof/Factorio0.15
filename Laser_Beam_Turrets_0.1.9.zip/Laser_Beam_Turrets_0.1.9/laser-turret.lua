
data:extend({
{
    type = "beam",
    name = "laser-beam-red",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = 20,
	light = {intensity = 0.5, size = 10},
    working_sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }
	  
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "damage",
            damage = { amount = 20, type = "laser"}
          }
        }
      }
    },
    head =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-head-2.png",
		  line_length = 16,
		  tint = {r=1.0, g=0.0, b=0.0},
      frame_count = 12,
      x = 45*4,
		  width = 45,
		  height = 1,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    tail =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-tail-3.png",
		  line_length = 16,
		  tint = {r=1.0, g=0.0, b=0.0},
      frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    body =
    {
      {
		  filename = "__Laser_Beam_Turrets__/laser-beam-body-2.png",
		  line_length = 16,
		  tint = {r=1.0, g=0.0, b=0.0},
		  frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
      
    }
  },
  {
    type = "beam",
    name = "laser-beam-blue",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = 20,
	light = {intensity = 0.5, size = 10},
    working_sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }
	  
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "damage",
            damage = { amount = 20, type = "laser"}
          }
        }
      }
    },
    head =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-head-2.png",
		  line_length = 16,
		  ttint = {r=0.2, g=0.3, b=1.0},
      frame_count = 12,
      x = 45*4,
		  width = 45,
		  height = 1,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    tail =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-tail-3.png",
		  line_length = 16,
		  tint = {r=0.2, g=0.3, b=1.0},
      frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    body =
    {
      {
		  filename = "__Laser_Beam_Turrets__/laser-beam-body-2.png",
		  line_length = 16,
		  tint = {r=0.2, g=0.3, b=1.0},
		  frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
      
    }
  },
  {
    type = "beam",
    name = "laser-beam-yellow",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = 20,
	light = {intensity = 0.5, size = 10},
    working_sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }
	  
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "damage",
            damage = { amount = 20, type = "laser"}
          }
        }
      }
    },
    head =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-head-2.png",
		  line_length = 16,
		  tint = {r=1, g=0.8, b=0.2},
      frame_count = 12,
      x = 45*4,
		  width = 45,
		  height = 1,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    tail =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-tail-3.png",
		  line_length = 16,
		  tint = {r=1, g=0.8, b=0.2},
      frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    body =
    {
      {
		  filename = "__Laser_Beam_Turrets__/laser-beam-body-2.png",
		  line_length = 16,
		  tint = {r=1, g=0.8, b=0.2},
		  frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
      
    }
  },
  {
    type = "beam",
    name = "laser-beam-green",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = 20,
	light = {intensity = 0.5, size = 10},
    working_sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }
	  
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "damage",
            damage = { amount = 20, type = "laser"}
          }
        }
      }
    },
    head =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-head-2.png",
		  line_length = 16,
		  tint = {r=0.0, g=1.0, b=0.0},
      frame_count = 12,
      x = 45*4,
		  width = 45,
		  height = 1,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    tail =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-tail-3.png",
		  line_length = 16,
		  tint = {r=0.0, g=1.0, b=0.0},
      frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    body =
    {
      {
		  filename = "__Laser_Beam_Turrets__/laser-beam-body-2.png",
		  line_length = 16,
		  tint = {r=0.0, g=1.0, b=0.0},
		  frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
      
    }
  },
  {
    type = "beam",
    name = "laser-beam-white",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = 20,
	light = {intensity = 0.5, size = 10},
    working_sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
	  {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }
	  
    },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "damage",
            damage = { amount = 20, type = "laser"}
          }
        }
      }
    },
    head =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-head-2.png",
		  line_length = 16,
		  tint = {r=1.0, g=1.0, b=1.0},
      frame_count = 12,
      x = 45*4,
		  width = 45,
		  height = 1,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    tail =
    {
		  filename = "__Laser_Beam_Turrets__/laser-beam-tail-3.png",
		  line_length = 16,
		  tint = {r=1.0, g=1.0, b=1.0},
      frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
    body =
    {
      {
		  filename = "__Laser_Beam_Turrets__/laser-beam-body-2.png",
		  line_length = 16,
		  tint = {r=1.0, g=1.0, b=1.0},
		  frame_count = 12,
      x = 48*4,
		  width = 48,
		  height = 24,
		  priority = "high",
		  animation_speed = 0.5,
		  blend_mode = "additive-soft"
		},
      
    }
  },



})
  
data.raw["electric-turret"]["laser-turret"].attack_parameters =
  {
    type = "beam",
    ammo_category = "electric",
    cooldown = 20,
    --projectile_center = {0, -0.2},
    --projectile_creation_distance = 1.4,
    range = 25,
    sound =
    {
      {
        filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
        volume = 0.9
      },
    {
        filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
        volume = 0.9
      },
    {
        filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
        volume = 0.9
      }

    },
    ammo_type =
    {
      category = "laser-turret",
      energy_consumption = "800kJ",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "beam",
          beam = "laser-beam-red",
          max_length = 25,
          duration = 20,
          source_offset = {0, -1.3},
        }
      }
    }
  }


if data.raw["electric-turret"]["bob-laser-turret-2"] then
	data.raw["electric-turret"]["bob-laser-turret-2"].attack_parameters =
	{
		type = "beam",
		ammo_category = "electric",
		cooldown = 20,
		damage_modifier = 1.5,
		range = 26.25,
		sound =
		{
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
				volume = 1
			}
		},
		ammo_type =
		{
			category = "laser-turret",
			energy_consumption = "1000kJ",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "beam",
					beam = "laser-beam-blue",
					max_length = 26.25,
					duration = 20,
					source_offset = {0, -1.3},
				}
			}
		}
	}

	data.raw["electric-turret"]["bob-laser-turret-3"].attack_parameters =
	{
		type = "beam",
		ammo_category = "electric",
		cooldown = 20,
		damage_modifier = 2.1,
		range = 27.5,
		sound =
		{
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
				volume = 1
			}
		},
		ammo_type =
		{
			category = "laser-turret",
			energy_consumption = "1200kJ",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "beam",
					beam = "laser-beam-green",
					max_length = 27.5,
					duration = 20,
					source_offset = {0, -1.3},
				}
			}
		}
	}

	data.raw["electric-turret"]["bob-laser-turret-4"].attack_parameters =
	{
		type = "beam",
		ammo_category = "electric",
		cooldown = 20,
		damage_modifier = 2.8,
		range = 28.75,
		sound =
		{
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
				volume = 1
			}
		},
		ammo_type =
		{
			category = "laser-turret",
			energy_consumption = "1400kJ",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "beam",
					beam = "laser-beam-yellow",
					max_length = 28.75,
					duration = 20,
					source_offset = {0, -1.3},
				}
			}
		}
	}

  data.raw["electric-turret"]["bob-laser-turret-5"].attack_parameters =
	{
		type = "beam",
		ammo_category = "electric",
		cooldown = 20,
		damage_modifier = 3.6,
		range = 30,
		sound =
		{
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-01.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-02.ogg",
				volume = 1
			},
			{
				filename = "__Laser_Beam_Turrets__/laser-beam-03.ogg",
				volume = 1
			}
		},
		ammo_type =
		{
			category = "laser-turret",
			energy_consumption = "1600kJ",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "beam",
					beam = "laser-beam-red",
					max_length = 30,
					duration = 20,
					source_offset = {0, -1.3},
				}
			}
		}
	}
end