if not bobmods then bobmods = {} end
if not bobmods.mining then bobmods.mining = {} end

data:extend(
{
  {
    type = "item-subgroup",
    name = "bob-tool",
    group = "production",
    order = "a-1",
  },
}
)


if settings.startup["bobmods-mining-miningdrills"].value == true then
  require("prototypes.drills")
end

if settings.startup["bobmods-mining-areadrills"].value == true then
  require("prototypes.areadrills")
end

if settings.startup["bobmods-mining-pumpjacks"].value == true then
  require("prototypes.pumpjacks")
end

if settings.startup["bobmods-mining-miningaxes"].value == true then
  require("prototypes.axes")
end

if settings.startup["bobmods-mining-waterminers"].value == true and data.raw["resource-category"]["water"] then
  require("prototypes.water-miner")
end

