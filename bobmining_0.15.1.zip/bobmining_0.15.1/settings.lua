data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-mining-miningdrills",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-mining-areadrills",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-mining-pumpjacks",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-mining-miningaxes",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-mining-waterminers",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
}
)


