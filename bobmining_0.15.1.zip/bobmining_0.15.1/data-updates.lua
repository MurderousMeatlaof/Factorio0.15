for i, drill in pairs(data.raw["mining-drill"]) do
  if not drill.storage_slots then drill.storage_slots = 6 end
end


if settings.startup["bobmods-mining-miningdrills"].value == true then
  require("prototypes.drill-updates")
end

if settings.startup["bobmods-mining-areadrills"].value == true then
  require("prototypes.areadrill-updates")
end

if settings.startup["bobmods-mining-pumpjacks"].value == true then
  require("prototypes.pumpjack-updates")
end

if settings.startup["bobmods-mining-miningaxes"].value == true then
  require("prototypes.axe-updates")
end

if settings.startup["bobmods-mining-waterminers"].value == true and data.raw["resource-category"]["water"] then
  require("prototypes.water-miner-updates")
end


