data:extend(
{
  {
    type = "resource-category",
    name = "angels-fissure",
  },
  {
    type = "resource-category",
    name = "angels-natural-gas",
  },
  {
    type = "item-subgroup",
    name = "angels-ores",
	group = "resource-refining",
	order = "m-aaa",
  },
}
)