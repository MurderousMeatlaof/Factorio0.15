data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-logistics-extremelyfastbelt",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-logistics-roboportrecipeupdate",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-logistics-flyingrobotframes",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-logistics-robotparts",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-logistics-robotrequireprevious",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-logistics-drainlessinserters",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
}
)


